# LifePals 1.4.1

Bodies on/off: `/pals bodies on|off|auto` (or `bodies.enabled` in config + `/pals reload`). Dodging style: `avoid.style`.


Admin-controlled simulated regulars for a Paper 1.21.11 lifesteal server. They chat in Hinglish/English, answer questions from a knowledge base you write, welcome players, react to deaths, and join/leave over time.

## Build (no PC needed)
1. Create a GitHub repo and upload everything in this folder (keep `.github/workflows/build.yml`).
2. Open the **Actions** tab, wait for the `build` run to finish, download the **LifePals** artifact (contains `LifePals.jar`).
   Or on a PC: `mvn package` (Java 21), jar is in `target/`.

## Install
1. Put `LifePals.jar` in `plugins/`, restart the server.
2. Edit `plugins/LifePals/knowledge.yml` (facts about YOUR server) and `config.yml` (chat format, mode).
3. `/pals reload`, then `/pals test hello` to try it privately.

## Modes (`brain.mode`)
- `OFFLINE`: no internet, uses knowledge.yml only.
- `API`: AI only. `AUTO`: AI first, offline fallback.
- API key: `brain.api-key` or env var `LIFEPALS_API_KEY`. Use a separate key with a low spend limit.
- `provider: anthropic` or `openai` (set `base-url` for Groq/OpenRouter/Gemini-compatible endpoints).

## Commands (permission `lifepals.admin`, op by default)
`/pals status | list | say <bot> <msg> | join <bot> | leave <bot> | reroll | toggle | test <msg> | reload`

## Safety design
- Bots are not players: no permissions, no commands, no inventories. They only broadcast text.
- Output filter drops links, IPs, command-looking lines, secrets, AI/prompt talk and blocked words.
- Input scrub removes links/IPs/color codes. API only receives persona prompt, your `facts`, and last ~8 chat lines.
- No network listeners, no file reads outside the plugin folder, no reflection, no other-plugin access.
- Remove: delete the jar and the `plugins/LifePals` folder. Nothing else is touched.

## v1.1 additions
- Bots appear in the tab list (needs ProtocolLib) with wobbling ping, and in the multiplayer-menu player count.
- IST-aware activity (fewer bots at night), goodbye/hello lines, `*typo` corrections, split messages, kill/death reactions.
- Gemini preset: provider `openai`, base-url `https://generativelanguage.googleapis.com/v1beta/openai`, model `gemini-2.5-flash-lite`.

## v1.4: spawn visits + dodging
- `bodies.mode: SPAWN_ONLY` (default): bots only appear at spawn during random "visits" (`bodies.visits.*`, about `per-day` a day, 10-40 min each, more likely in busy hours). Outside a visit nothing is at spawn. `/pals visit start|stop` to test. Set `mode: MIXED` to bring back wild standers.
- Trade / tpa / gift asks (chat or `/tpa /trade /msg /pay <bot>`) are dodged: fake request reply, bot walks away, excuse in chat or silence. Edit the `avoid:` messages to match your plugins' wording.

## v1.3: spawn roamers + wild standers
- `bodies.roamers` (default 2) bots walk around spawn; every 6-14 min one heads out (says it's going rtp) and a wild bot takes its place.
- All other online bots stand at random spots in a wilderness ring (`bodies.wild.min-radius/max-radius`), only visible to players who come near; they relocate every 10-25 min.

## v1.2: in-world bodies
- Bots walk around as real-looking players (client-side packets, nothing on the server): they wander a zone, look at people, swing arms, approach players and sometimes talk.
- Hit them and they flinch, complain in chat, and after `bodies.hits-to-die` hits they "die" and respawn later.
- Stand where you want them and run `/pals zone 30`. `/pals where` shows positions. Skins are Steve/Alex by default; add `skin_value` + `skin_signature` per persona (from mineskin.org) for custom skins.
- If GrimAC flags hits on bots, set `bodies.enabled: false`.

## Honest limits
- Bots have no in-world body and are not in `/list`. Tab entries are client-side only.
- TAB plugin may sort or restyle unknown entries; test it.
- Chat lines from real players go to the API provider in API/AUTO mode. Mention it in your rules/privacy notes.
