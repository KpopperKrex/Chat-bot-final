package dev.lifepals;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.ProtocolManager;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.wrappers.EnumWrappers;
import com.comphenix.protocol.wrappers.PlayerInfoData;
import com.comphenix.protocol.wrappers.WrappedChatComponent;
import com.comphenix.protocol.wrappers.WrappedGameProfile;
import com.comphenix.protocol.wrappers.WrappedSignedProperty;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

/**
 * Shows bots in the tab list by sending player-info packets (ProtocolLib).
 * Purely client-side entries: no entity, no real player, nothing is stored on the server.
 * Every packet call is wrapped, so a ProtocolLib mismatch only disables this feature.
 */
final class TabList {
    private final LifePals plugin;
    private final ProtocolManager pm = ProtocolLibrary.getProtocolManager();
    private final Random rnd = new Random();
    private final Map<UUID, BotManager.Bot> shown = new HashMap<>();
    private final Map<UUID, Integer> basePing = new HashMap<>();
    private boolean failed;

    TabList(LifePals plugin) {
        this.plugin = plugin;
    }

    boolean works() {
        return !failed;
    }

    /** Stable fake UUID per bot name (different from real offline-mode UUIDs). */
    static UUID uuidFor(String name) {
        return UUID.nameUUIDFromBytes(("LifePals:" + name).getBytes(StandardCharsets.UTF_8));
    }

    /** Make the tab list match exactly the given online bots (adds new, removes gone). */
    void sync(List<BotManager.Bot> online) {
        if (failed) {
            return;
        }
        Map<UUID, BotManager.Bot> want = new HashMap<>();
        for (BotManager.Bot b : online) {
            want.put(uuidFor(b.p.name()), b);
        }
        Set<UUID> remove = new HashSet<>(shown.keySet());
        remove.removeAll(want.keySet());
        List<BotManager.Bot> add = new ArrayList<>();
        for (Map.Entry<UUID, BotManager.Bot> e : want.entrySet()) {
            if (!shown.containsKey(e.getKey())) {
                add.add(e.getValue());
            }
        }
        if (!remove.isEmpty()) {
            sendRemove(remove);
        }
        if (!add.isEmpty()) {
            sendAdd(add, new ArrayList<>(Bukkit.getOnlinePlayers()));
        }
        shown.clear();
        shown.putAll(want);
    }

    /** A player just joined: give them the current bot entries. */
    void showAllTo(Player p) {
        if (failed || shown.isEmpty() || !p.isOnline()) {
            return;
        }
        sendAdd(new ArrayList<>(shown.values()), List.of(p));
    }

    /** Wiggle the ping bars a little, like a real connection. */
    void refreshPing() {
        if (failed || shown.isEmpty()) {
            return;
        }
        try {
            List<PlayerInfoData> data = new ArrayList<>();
            for (Map.Entry<UUID, BotManager.Bot> e : shown.entrySet()) {
                data.add(info(e.getKey(), e.getValue().p));
            }
            PacketContainer packet = pm.createPacket(PacketType.Play.Server.PLAYER_INFO);
            packet.getPlayerInfoActions().write(0, EnumSet.of(EnumWrappers.PlayerInfoAction.UPDATE_LATENCY));
            packet.getPlayerInfoDataLists().write(1, data);
            broadcast(packet, new ArrayList<>(Bukkit.getOnlinePlayers()));
        } catch (Throwable t) {
            fail(t);
        }
    }

    /** Remove every entry (plugin disable / feature off). */
    void clear() {
        if (failed || shown.isEmpty()) {
            return;
        }
        sendRemove(new HashSet<>(shown.keySet()));
        shown.clear();
    }

    // ------------------------------------------------------------------ packets

    private PlayerInfoData info(UUID id, Persona persona) {
        String name = persona.name();
        int base = basePing.computeIfAbsent(id, k -> 25 + rnd.nextInt(120));
        int ping = Math.max(8, base + rnd.nextInt(25) - 12);
        WrappedGameProfile profile = new WrappedGameProfile(id, name);
        if (persona.skinValue() != null && persona.skinSig() != null) {
            profile.getProperties().put("textures",
                    new WrappedSignedProperty("textures", persona.skinValue(), persona.skinSig()));
        }
        return new PlayerInfoData(profile, ping,
                EnumWrappers.NativeGameMode.SURVIVAL, WrappedChatComponent.fromText(name));
    }

    private void sendAdd(List<BotManager.Bot> bots, Collection<? extends Player> targets) {
        try {
            List<PlayerInfoData> data = new ArrayList<>();
            for (BotManager.Bot b : bots) {
                data.add(info(uuidFor(b.p.name()), b.p));
            }
            PacketContainer packet = pm.createPacket(PacketType.Play.Server.PLAYER_INFO);
            packet.getPlayerInfoActions().write(0, EnumSet.of(
                    EnumWrappers.PlayerInfoAction.ADD_PLAYER,
                    EnumWrappers.PlayerInfoAction.UPDATE_LISTED,
                    EnumWrappers.PlayerInfoAction.UPDATE_LATENCY,
                    EnumWrappers.PlayerInfoAction.UPDATE_GAME_MODE));
            packet.getPlayerInfoDataLists().write(1, data);
            broadcast(packet, targets);
        } catch (Throwable t) {
            fail(t);
        }
    }

    private void sendRemove(Set<UUID> ids) {
        try {
            PacketContainer packet = pm.createPacket(PacketType.Play.Server.PLAYER_INFO_REMOVE);
            packet.getUUIDLists().write(0, new ArrayList<>(ids));
            broadcast(packet, new ArrayList<>(Bukkit.getOnlinePlayers()));
        } catch (Throwable t) {
            fail(t);
        }
    }

    private void broadcast(PacketContainer packet, Collection<? extends Player> targets) {
        for (Player p : targets) {
            try {
                pm.sendServerPacket(p, packet);
            } catch (Exception e) {
                fail(e);
                return;
            }
        }
    }

    private void fail(Throwable t) {
        if (!failed) {
            failed = true;
            plugin.getLogger().warning("Tab list feature disabled (ProtocolLib problem: "
                    + t.getClass().getSimpleName() + "). Chat bots still work.");
        }
    }
}
