package dev.lifepals;

import com.destroystokyo.paper.event.server.PaperServerListPingEvent;
import java.io.File;
import java.io.IOException;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CopyOnWriteArrayList;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.scheduler.BukkitTask;

/** Owns the roster and decides who says what and when. Bots only ever produce chat text and tab entries. */
final class BotManager {

    static final class Bot {
        final Persona p;
        volatile boolean online;
        volatile long lastSpoke;

        Bot(Persona p) {
            this.p = p;
        }
    }

    /** Busy-ness by hour of day (IST by default): quiet at night, lively in the evening. */
    private static final double[] ACTIVITY = {
            0.55, 0.40, 0.25, 0.20, 0.20, 0.20, 0.25, 0.35,
            0.40, 0.45, 0.55, 0.60, 0.60, 0.60, 0.65, 0.75,
            0.85, 0.90, 1.00, 1.00, 1.00, 1.00, 0.90, 0.70};

    private static final Set<String> TPA_CMDS = Set.of("tpa", "tpask", "tpahere", "call", "etpa", "etpahere");
    private static final Set<String> TRADE_CMDS = Set.of("trade", "etrade");
    private static final Set<String> MSG_CMDS = Set.of("msg", "tell", "w", "whisper", "m", "pm", "emsg", "etell");

    private final LifePals plugin;
    private final Random rnd = new Random();
    private final List<Bot> roster = new CopyOnWriteArrayList<>();
    private final Deque<ChatLine> history = new ArrayDeque<>();
    private final LegacyComponentSerializer legacy = LegacyComponentSerializer.legacyAmpersand();
    private BukkitTask task;
    private TabList tab;
    private Bodies bodies;
    private boolean enabled = true;
    private long nextChurn;
    private long nextAmbient;
    private long lastAny;
    private int tickCount;

    BotManager(LifePals plugin) {
        this.plugin = plugin;
    }

    private FileConfiguration cfg() {
        return plugin.getConfig();
    }

    // ---------------------------------------------------------------- lifecycle

    void start() {
        setupTab();
        reload();
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 100L, 100L);
    }

    void stop() {
        if (task != null) {
            task.cancel();
        }
        if (bodies != null) {
            bodies.clear();
        }
        if (tab != null) {
            tab.clear();
        }
    }

    private void setupTab() {
        tab = null;
        bodies = null;
        if (!cfg().getBoolean("tablist.enabled", true)) {
            return;
        }
        if (!Bukkit.getPluginManager().isPluginEnabled("ProtocolLib")) {
            plugin.getLogger().info("ProtocolLib not found: bots will not appear in the tab list.");
            return;
        }
        try {
            tab = new TabList(plugin);
        } catch (Throwable t) {
            plugin.getLogger().warning("Could not start tab list: " + t.getClass().getSimpleName());
            tab = null;
            return;
        }
        if (cfg().getBoolean("bodies.enabled", true)) {
            try {
                bodies = new Bodies(plugin, this, tab);
            } catch (Throwable t) {
                plugin.getLogger().warning("Could not start in-world bodies: " + t.getClass().getSimpleName());
                bodies = null;
            }
        }
    }

    void reload() {
        enabled = cfg().getBoolean("enabled", true);
        applyBodiesConfig();
        if (bodies != null) {
            bodies.reload();
        }
        if (tab != null) {
            tab.clear();
        }
        loadRoster(false);
        long now = System.currentTimeMillis();
        nextChurn = now + ms(rand(cfg().getInt("bots.churn-min-seconds", 150), cfg().getInt("bots.churn-max-seconds", 480)));
        nextAmbient = now + ms(rand(cfg().getInt("chat.ambient-min-seconds", 100), cfg().getInt("chat.ambient-max-seconds", 260)));
        bringOnlineSilently();
    }

    void reroll() {
        if (bodies != null) {
            bodies.reset();
        }
        if (tab != null) {
            tab.clear();
        }
        loadRoster(true);
        bringOnlineSilently();
    }

    // ---------------------------------------------------------------- roster

    private List<Persona> loadPool() {
        YamlConfiguration y = YamlConfiguration.loadConfiguration(new File(plugin.getDataFolder(), "personas.yml"));
        List<Persona> out = new ArrayList<>();
        for (Map<?, ?> m : y.getMapList("personas")) {
            try {
                out.add(Persona.fromMap(m));
            } catch (Exception ignored) {
                // skip malformed persona
            }
        }
        return out;
    }

    private void loadRoster(boolean fresh) {
        List<Persona> pool = loadPool();
        File f = new File(plugin.getDataFolder(), "data.yml");
        List<String> saved = fresh ? List.of() : YamlConfiguration.loadConfiguration(f).getStringList("roster");
        int want = Math.max(1, cfg().getInt("bots.count", 8));

        roster.clear();
        for (String n : saved) {
            for (Persona p : pool) {
                if (p.name().equalsIgnoreCase(n) && roster.size() < want) {
                    roster.add(new Bot(p));
                    break;
                }
            }
        }
        List<Persona> shuffled = new ArrayList<>(pool);
        Collections.shuffle(shuffled, rnd);
        for (Persona p : shuffled) {
            if (roster.size() >= want) {
                break;
            }
            boolean already = roster.stream().anyMatch(b -> b.p.name().equalsIgnoreCase(p.name()));
            if (!already && nameIsFree(p.name())) {
                roster.add(new Bot(p));
            }
        }

        YamlConfiguration d = YamlConfiguration.loadConfiguration(f);
        List<String> names = new ArrayList<>();
        for (Bot b : roster) {
            names.add(b.p.name());
        }
        d.set("roster", names);
        try {
            d.save(f);
        } catch (IOException e) {
            plugin.getLogger().warning("Could not save data.yml");
        }
    }

    /** Never reuse the name of a real player who is online or has played here. */
    private boolean nameIsFree(String name) {
        return Bukkit.getPlayerExact(name) == null && Bukkit.getOfflinePlayerIfCached(name) == null;
    }

    private void bringOnlineSilently() {
        for (Bot b : roster) {
            b.online = false;
        }
        List<Bot> shuffled = new ArrayList<>(roster);
        Collections.shuffle(shuffled, rnd);
        int n = Math.min(desiredOnline(), shuffled.size());
        for (int i = 0; i < n; i++) {
            shuffled.get(i).online = true;
        }
        tabSync();
    }

    List<Bot> roster() {
        return roster;
    }

    Bot find(String name) {
        for (Bot b : roster) {
            if (b.p.name().equalsIgnoreCase(name)) {
                return b;
            }
        }
        return null;
    }

    private List<Bot> onlineBots() {
        List<Bot> out = new ArrayList<>();
        for (Bot b : roster) {
            if (b.online) {
                out.add(b);
            }
        }
        return out;
    }

    int onlineCount() {
        return onlineBots().size();
    }

    boolean enabled() {
        return enabled;
    }

    void setEnabled(boolean e) {
        enabled = e;
        tabSync();
    }

    boolean tabActive() {
        return tab != null && tab.works();
    }

    private void tabSync() {
        List<Bot> list = enabled ? onlineBots() : List.of();
        if (tab != null) {
            tab.sync(list);
        }
        if (bodies != null) {
            bodies.sync(list);
        }
    }

    /** Bodies on/off: data.yml override (/pals bodies) wins over config.yml (bodies.enabled). */
    private void applyBodiesConfig() {
        YamlConfiguration d = YamlConfiguration.loadConfiguration(new File(plugin.getDataFolder(), "data.yml"));
        boolean wanted = d.contains("bodies-override") ? d.getBoolean("bodies-override") : cfg().getBoolean("bodies.enabled", true);
        boolean want = tab != null && wanted;
        if (want && bodies == null) {
            try {
                bodies = new Bodies(plugin, this, tab);
            } catch (Throwable t) {
                plugin.getLogger().warning("Could not start in-world bodies: " + t.getClass().getSimpleName());
                bodies = null;
            }
        } else if (!want && bodies != null) {
            bodies.clear();
            bodies = null;
        }
    }

    /** /pals bodies on|off|auto */
    String setBodies(String mode) {
        File f = new File(plugin.getDataFolder(), "data.yml");
        YamlConfiguration d = YamlConfiguration.loadConfiguration(f);
        switch (mode.toLowerCase(Locale.ROOT)) {
            case "on" -> d.set("bodies-override", true);
            case "off" -> d.set("bodies-override", false);
            case "auto" -> d.set("bodies-override", null);
            default -> {
                return "/pals bodies <on|off|auto>";
            }
        }
        try {
            d.save(f);
        } catch (IOException e) {
            return "Could not save data.yml";
        }
        applyBodiesConfig();
        tabSync();
        if (tab == null) {
            return "Bodies need the tab list (ProtocolLib). Not available right now.";
        }
        return "Bodies are now " + (bodies != null ? "ON" : "OFF") + " (" + mode.toLowerCase(Locale.ROOT)
                + "). Chat and tab list are unaffected.";
    }

    boolean bodiesActive() {
        return bodies != null;
    }

    void forget(Player p) {
        if (bodies != null) {
            bodies.forget(p.getUniqueId());
        }
    }

    boolean setZone(org.bukkit.Location l, int radius) {
        if (bodies == null) {
            return false;
        }
        bodies.setZone(l, radius);
        tabSync();
        return true;
    }

    List<String> where() {
        return bodies == null ? List.of("bodies are off (needs ProtocolLib + bodies.enabled)") : bodies.where();
    }

    double busy() {
        return activity();
    }

    String visit(boolean start) {
        return bodies == null ? "Bodies are off." : bodies.forceVisit(start);
    }

    // ---------------------------------------------------------------- avoiding trade / tpa / gifts

    private static boolean isAvoidIntent(String text) {
        String t = text.toLowerCase(Locale.ROOT);
        Set<String> tokens = new HashSet<>(Arrays.asList(t.split("[^a-z0-9]+")));
        for (String w : new String[]{"trade", "trades", "trading", "tpa", "tpahere", "tpaccept", "tp", "teleport",
                "gift", "give", "dedo", "dede", "send"}) {
            if (tokens.contains(w)) {
                return true;
            }
        }
        return t.contains("de do") || t.contains("de de") || t.contains("free heart") || t.contains("heart de");
    }

    /** Which kind of line to use for a dodge: excuse, blunt refusal, or null = say nothing. */
    private String avoidPath() {
        String m = cfg().getString("avoid.style", "MIXED").toUpperCase(Locale.ROOT);
        switch (m) {
            case "IGNORE":
                return null;
            case "REFUSE":
                return "chatter.refuse";
            case "EXCUSE":
                return "chatter.avoid";
            default:
                return rnd.nextBoolean() ? "chatter.avoid" : "chatter.refuse";
        }
    }

    private void dodgeLine(Bot b, String player) {
        String path = avoidPath();
        if (path != null) {
            sayLine(b, path, player);
        }
    }

    /** Casual excuse in chat (sometimes ignores), and walks away from the asker. */
    private void dodge(Bot b, String player) {
        if (bodies != null) {
            bodies.avoid(b.p.name(), Bukkit.getPlayerExact(player));
        }
        if (rnd.nextDouble() < 0.75) {
            dodgeLine(b, player);
        }
    }

    private void fake(Player p, String key, String def, String name, String message) {
        p.sendMessage(legacy.deserialize(cfg().getString(key, def)
                .replace("{name}", name).replace("{message}", message)));
    }

    /**
     * /tpa, /trade, /msg, /pay aimed at an online bot: the server would say "player not found",
     * which gives the bot away. Intercept, show a believable reply, then the bot dodges.
     */
    void onCommand(PlayerCommandPreprocessEvent e) {
        if (!enabled || !cfg().getBoolean("avoid.enabled", true)) {
            return;
        }
        String raw = e.getMessage();
        if (raw.length() < 3 || raw.charAt(0) != '/') {
            return;
        }
        String[] parts = raw.substring(1).trim().split("\\s+", 3);
        if (parts.length < 2) {
            return;
        }
        String cmd = parts[0].toLowerCase(Locale.ROOT);
        int colon = cmd.indexOf(':');
        if (colon >= 0) {
            cmd = cmd.substring(colon + 1);
        }
        String kind;
        if (TPA_CMDS.contains(cmd)) {
            kind = "tpa";
        } else if (TRADE_CMDS.contains(cmd)) {
            kind = "trade";
        } else if (MSG_CMDS.contains(cmd)) {
            kind = "msg";
        } else if (cmd.equals("pay")) {
            kind = "pay";
        } else {
            return;
        }
        Bot b = null;
        for (Bot x : roster) {
            if (x.online && x.p.name().equalsIgnoreCase(parts[1])) {
                b = x;
                break;
            }
        }
        if (b == null) {
            return;
        }
        e.setCancelled(true);
        Player p = e.getPlayer();
        Bot bot = b;
        String name = b.p.name();
        String text = parts.length > 2 ? Guard.in(parts[2]) : "";
        switch (kind) {
            case "tpa", "trade" -> {
                fake(p, kind.equals("tpa") ? "avoid.reply-tpa" : "avoid.reply-trade",
                        kind.equals("tpa") ? "&6Request sent to &c{name}&6." : "&aTrade request sent to &e{name}&a.", name, "");
                if (bodies != null) {
                    bodies.avoid(name, p);
                }
                double roll = rnd.nextDouble();
                long d = 80 + rnd.nextInt(200);
                if (roll < 0.45) {
                    Bukkit.getScheduler().runTaskLater(plugin, () -> dodgeLine(bot, p.getName()), d);
                } else if (roll < 0.75 && kind.equals("tpa")) {
                    Bukkit.getScheduler().runTaskLater(plugin, () -> {
                        if (p.isOnline()) {
                            fake(p, "avoid.deny-tpa", "&c{name} denied your teleport request.", name, "");
                        }
                    }, d + 100);
                }
            }
            case "msg" -> {
                if (text.isBlank()) {
                    p.sendMessage(legacy.deserialize("&cUsage: /" + cmd + " <player> <message>"));
                    return;
                }
                fake(p, "avoid.reply-msg", "&7[&6me &7-> &c{name}&7] &f{message}", name, text);
                if (rnd.nextDouble() < 0.6) {
                    whisperBack(bot, p, text);
                }
            }
            default -> {
                fake(p, "avoid.reply-pay", "&cYou can't pay that player right now.", name, "");
                if (rnd.nextDouble() < 0.3) {
                    Bukkit.getScheduler().runTaskLater(plugin, () -> dodgeLine(bot, p.getName()), 100 + rnd.nextInt(150));
                }
            }
        }
    }

    /** Private reply to a /msg, built by the same brain; dodges if it was a trade/tpa/gift ask. */
    private void whisperBack(Bot b, Player p, String text) {
        if (isAvoidIntent(text)) {
            String ap = avoidPath();
            String line = ap == null ? null : plugin.offline().pickLine(ap);
            if (line != null) {
                deliverWhisper(b, p, line.replace("{player}", p.getName()));
            }
            return;
        }
        ChatLine line = new ChatLine(p.getName(), text, false);
        List<ChatLine> hist = new ArrayList<>(snapshot());
        hist.add(line);
        generate(b.p, hist, line, true).thenAccept(r -> {
            if (r != null && !r.isBlank()) {
                Bukkit.getScheduler().runTask(plugin, () -> deliverWhisper(b, p, r));
            }
        });
    }

    private void deliverWhisper(Bot b, Player p, String raw) {
        String clean = Guard.out(raw, cfg().getStringList("blocked-words"), plugin.api().key());
        if (clean == null) {
            return;
        }
        String msg = Humanizer.apply(clean, b.p, rnd, 0).text();
        long delay = Humanizer.delayTicks(msg, rnd) + 40;
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (p.isOnline() && b.online && enabled) {
                fake(p, "avoid.reply-msg-from", "&7[&c{name} &7-> &6me&7] &f{message}", b.p.name(), msg);
            }
        }, delay);
    }

    /** Called by in-world bodies when a bot "talks" to or about a player. */
    void sayLine(Bot b, String path, String player) {
        if (!enabled || !b.online) {
            return;
        }
        String line = plugin.offline().pickLine(path);
        if (line != null) {
            speak(b, line.replace("{player}", player), 1, 0);
        }
    }

    // ---------------------------------------------------------------- time-of-day

    private double activity() {
        if (!cfg().getBoolean("chat.time-of-day-scaling", true)) {
            return 1.0;
        }
        try {
            ZoneId z = ZoneId.of(cfg().getString("chat.timezone", "Asia/Kolkata"));
            return ACTIVITY[ZonedDateTime.now(z).getHour()];
        } catch (Exception e) {
            return 1.0;
        }
    }

    private int desiredOnline() {
        int min = cfg().getInt("bots.min-online", 3);
        int max = Math.max(min, cfg().getInt("bots.max-online", 6));
        int n = (int) Math.round(min + (max - min) * activity());
        return Math.max(1, Math.min(n, roster.size()));
    }

    // ---------------------------------------------------------------- join / leave

    void join(Bot b) {
        if (b.online) {
            return;
        }
        b.online = true;
        tabSync();
        if (cfg().getBoolean("messages.show-join-leave", true)) {
            announce(cfg().getString("messages.join", "&e{name} joined the game"), b);
        }
        if (rnd.nextDouble() < cfg().getDouble("chat.join-say-chance", 0.4)) {
            String line = plugin.offline().pickLine("chatter.join-say");
            if (line != null) {
                speak(b, line, 1, 40 + rnd.nextInt(80));
            }
        }
    }

    void leave(Bot b) {
        if (!b.online) {
            return;
        }
        b.online = false;
        tabSync();
        if (cfg().getBoolean("messages.show-join-leave", true)) {
            announce(cfg().getString("messages.leave", "&e{name} left the game"), b);
        }
    }

    /** Sometimes says bye first, then leaves a few seconds later. */
    private void leaveNaturally(Bot b) {
        if (rnd.nextDouble() < cfg().getDouble("chat.goodbye-chance", 0.6)) {
            String line = plugin.offline().pickLine("chatter.bye");
            if (line != null) {
                speak(b, line, 1, 0);
                Bukkit.getScheduler().runTaskLater(plugin, () -> leave(b), 240L + rnd.nextInt(120));
                return;
            }
        }
        leave(b);
    }

    private void announce(String fmt, Bot b) {
        Bukkit.broadcast(legacy.deserialize(fmt.replace("{name}", b.p.name())));
    }

    // ---------------------------------------------------------------- scheduler tick

    private void tick() {
        if (!enabled) {
            return;
        }
        long now = System.currentTimeMillis();
        tickCount++;
        if (tab != null && tickCount % 6 == 0) {
            tab.refreshPing();
        }
        if (now >= nextChurn) {
            churn();
            nextChurn = now + ms(rand(cfg().getInt("bots.churn-min-seconds", 150), cfg().getInt("bots.churn-max-seconds", 480)));
        }
        if (now >= nextAmbient) {
            double act = Math.max(0.25, activity());
            int lo = (int) (cfg().getInt("chat.ambient-min-seconds", 100) / act);
            int hi = (int) (cfg().getInt("chat.ambient-max-seconds", 260) / act);
            nextAmbient = now + ms(rand(lo, hi));
            boolean needPlayers = cfg().getBoolean("chat.only-when-players-online", true);
            if (!needPlayers || !Bukkit.getOnlinePlayers().isEmpty()) {
                Bot b = pickSpeaker(null);
                if (b != null) {
                    respond(b, null, false, 0);
                }
            }
        }
    }

    private void churn() {
        List<Bot> onl = onlineBots();
        int on = onl.size();
        int target = desiredOnline();
        if (on < target) {
            List<Bot> off = new ArrayList<>();
            for (Bot b : roster) {
                if (!b.online) {
                    off.add(b);
                }
            }
            if (!off.isEmpty()) {
                join(off.get(rnd.nextInt(off.size())));
            }
        } else if (on > target || (on > cfg().getInt("bots.min-online", 3) && rnd.nextDouble() < 0.3)) {
            if (!onl.isEmpty()) {
                leaveNaturally(onl.get(rnd.nextInt(onl.size())));
            }
        }
    }

    // ---------------------------------------------------------------- events from real players

    void onPlayerChat(String player, String rawText) {
        // may be called from the async chat thread: hop to main thread
        Bukkit.getScheduler().runTask(plugin, () -> handleChat(player, rawText));
    }

    private void handleChat(String player, String rawText) {
        if (!enabled) {
            return;
        }
        String clean = Guard.in(rawText);
        if (clean.isBlank()) {
            return;
        }
        ChatLine line = new ChatLine(player, clean, false);
        addHistory(line);

        Bot direct = findMentioned(clean);
        if (direct != null) {
            if (isAvoidIntent(clean)) {
                dodge(direct, player);
                return;
            }
            respond(direct, line, true, 0);
            return;
        }
        if (rnd.nextDouble() < cfg().getDouble("chat.reply-chance-general", 0.22)) {
            Bot b = pickSpeaker(null);
            if (b != null) {
                respond(b, line, false, 0);
            }
        }
    }

    /** A real player joined: show them the bots in tab and maybe welcome them. */
    void onRealJoin(Player p) {
        if (tab != null) {
            Bukkit.getScheduler().runTaskLater(plugin, () -> tab.showAllTo(p), 20L);
        }
        react("chatter.welcome", p.getName(), "", cfg().getDouble("chat.welcome-chance", 0.45), 60 + rnd.nextInt(100));
    }

    void deathReact(String player, String killer) {
        double chance = cfg().getDouble("chat.death-react-chance", 0.4);
        if (killer != null && !killer.isBlank() && rnd.nextBoolean()) {
            react("chatter.kill-react", player, killer, chance, 30 + rnd.nextInt(60));
        } else {
            react("chatter.death-react", player, killer == null ? "" : killer, chance, 30 + rnd.nextInt(60));
        }
    }

    private void react(String path, String player, String killer, double chance, long extraTicks) {
        if (!enabled || rnd.nextDouble() > chance) {
            return;
        }
        Bot b = pickSpeaker(null);
        String line = plugin.offline().pickLine(path);
        if (b == null || line == null) {
            return;
        }
        speak(b, line.replace("{player}", player).replace("{killer}", killer), 1, extraTicks);
    }

    private Bot findMentioned(String text) {
        Set<String> tokens = new HashSet<>(Arrays.asList(text.toLowerCase(Locale.ROOT).split("[^a-z0-9_]+")));
        for (Bot b : roster) {
            if (!b.online) {
                continue;
            }
            for (String a : b.p.aliases()) {
                if (tokens.contains(a)) {
                    return b;
                }
            }
        }
        return null;
    }

    private Bot pickSpeaker(Bot exclude) {
        long now = System.currentTimeMillis();
        long cd = cfg().getInt("chat.bot-cooldown-seconds", 10) * 1000L;
        List<Bot> c = new ArrayList<>();
        for (Bot b : roster) {
            if (b.online && b != exclude && now - b.lastSpoke > cd) {
                c.add(b);
            }
        }
        return c.isEmpty() ? null : c.get(rnd.nextInt(c.size()));
    }

    // ---------------------------------------------------------------- server list

    /** Adds online bots to the multiplayer-menu player count and hover list. */
    void decoratePing(PaperServerListPingEvent e) {
        if (!enabled || !cfg().getBoolean("tablist.server-list-count", true)) {
            return;
        }
        List<Bot> onl = onlineBots();
        if (onl.isEmpty()) {
            return;
        }
        e.setNumPlayers(e.getNumPlayers() + onl.size());
        for (Bot b : onl) {
            e.getListedPlayers().add(new PaperServerListPingEvent.ListedPlayerInfo(b.p.name(), TabList.uuidFor(b.p.name())));
        }
    }

    // ---------------------------------------------------------------- speaking

    private void respond(Bot b, ChatLine trig, boolean direct, int depth) {
        long now = System.currentTimeMillis();
        long gap = cfg().getInt("chat.min-gap-seconds", 3) * 1000L;
        if (now - lastAny < gap) {
            return;
        }
        lastAny = now; // reserve the slot so bursts cannot happen
        List<ChatLine> hist = snapshot();
        generate(b.p, hist, trig, direct).thenAccept(r -> {
            if (r != null && !r.isBlank()) {
                Bukkit.getScheduler().runTask(plugin, () -> speak(b, r, depth, 0));
            }
        });
    }

    private CompletableFuture<String> generate(Persona p, List<ChatLine> hist, ChatLine trig, boolean direct) {
        String mode = cfg().getString("brain.mode", "AUTO").toUpperCase(Locale.ROOT);
        if (mode.equals("OFFLINE") || !plugin.api().available()) {
            if (mode.equals("API")) {
                return CompletableFuture.completedFuture("");
            }
            return CompletableFuture.completedFuture(offlineAnswer(p, trig, direct));
        }
        return plugin.api().reply(p, hist, trig, direct).thenApply(r -> {
            if (r != null) {
                return r;
            }
            return mode.equals("AUTO") ? offlineAnswer(p, trig, direct) : "";
        });
    }

    private String offlineAnswer(Persona p, ChatLine trig, boolean direct) {
        String s = trig == null ? plugin.offline().ambient(p) : plugin.offline().reply(p, trig, direct);
        return s == null ? "" : s;
    }

    /** Main thread. Filters, humanizes (typo/fix/split), waits a typing delay, then posts. */
    private void speak(Bot b, String raw, int depth, long extraTicks) {
        String clean = Guard.out(raw, cfg().getStringList("blocked-words"), plugin.api().key());
        if (clean == null) {
            return;
        }
        Humanizer.Result res = Humanizer.apply(clean, b.p, rnd, cfg().getDouble("chat.typo-fix-chance", 0.35));
        String msg = res.text();

        String first = msg;
        String second = null;
        int spaces = msg.length() - msg.replace(" ", "").length();
        if (spaces >= 4 && res.fix() == null && rnd.nextDouble() < cfg().getDouble("chat.split-message-chance", 0.10)) {
            int cut = msg.indexOf(' ', msg.length() / 2);
            if (cut > 0) {
                first = msg.substring(0, cut);
                second = msg.substring(cut + 1);
            }
        }
        String firstFinal = first;
        String secondFinal = second;
        long delay = Humanizer.delayTicks(first, rnd) + extraTicks;
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!b.online || !enabled) {
                return;
            }
            send(b, firstFinal);
            if (secondFinal != null) {
                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    if (b.online && enabled) {
                        send(b, secondFinal);
                    }
                }, 25L + rnd.nextInt(30));
            } else if (res.fix() != null) {
                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    if (b.online && enabled) {
                        send(b, res.fix());
                    }
                }, 30L + rnd.nextInt(40));
            }
            if (depth < 1 && rnd.nextDouble() < cfg().getDouble("chat.chain-chance", 0.12)) {
                Bot other = pickSpeaker(b);
                if (other != null) {
                    ChatLine line = new ChatLine(b.p.name(), msg, true);
                    Bukkit.getScheduler().runTaskLater(plugin, () -> respond(other, line, false, 1), 60L + rnd.nextInt(60));
                }
            }
        }, delay);
    }

    private void send(Bot b, String msg) {
        String fmt = cfg().getString("chat.format", "&7{name} &8» &f{message}");
        // msg is already stripped of color codes by Guard, so it cannot inject formatting
        Bukkit.broadcast(legacy.deserialize(fmt.replace("{name}", b.p.name()).replace("{message}", msg)));
        b.lastSpoke = System.currentTimeMillis();
        lastAny = b.lastSpoke;
        addHistory(new ChatLine(b.p.name(), msg, true));
    }

    /** Admin command: make a bot say something (still filtered, no typing delay). */
    boolean forceSay(Bot b, String text) {
        String clean = Guard.out(text, cfg().getStringList("blocked-words"), plugin.api().key());
        if (clean == null) {
            return false;
        }
        if (!b.online) {
            join(b);
        }
        send(b, clean);
        return true;
    }

    /** Admin command: run the brain privately and hand the answer back (not broadcast). */
    CompletableFuture<String> test(String fromName, String text) {
        Bot b = null;
        for (Bot x : roster) {
            if (x.online) {
                b = x;
                break;
            }
        }
        if (b == null) {
            return CompletableFuture.completedFuture(null);
        }
        ChatLine line = new ChatLine(fromName, Guard.in(text), false);
        List<ChatLine> hist = new ArrayList<>(snapshot());
        hist.add(line);
        Persona p = b.p;
        return generate(p, hist, line, true).thenApply(r -> r == null || r.isBlank() ? null : p.name() + ": " + r);
    }

    // ---------------------------------------------------------------- history & helpers

    private void addHistory(ChatLine l) {
        int max = Math.max(2, cfg().getInt("chat.history-lines", 8));
        synchronized (history) {
            history.addLast(l);
            while (history.size() > max) {
                history.removeFirst();
            }
        }
    }

    private List<ChatLine> snapshot() {
        synchronized (history) {
            return new ArrayList<>(history);
        }
    }

    private int rand(int min, int max) {
        if (max <= min) {
            return min;
        }
        return min + rnd.nextInt(max - min + 1);
    }

    private static long ms(int seconds) {
        return seconds * 1000L;
    }
}
