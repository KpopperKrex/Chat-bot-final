package dev.lifepals;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/** Works with zero internet: keyword answers + canned chatter from knowledge.yml. */
final class OfflineBrain {
    private final LifePals plugin;
    private final Random rnd = new Random();
    private final Deque<String> recent = new ArrayDeque<>();

    OfflineBrain(LifePals plugin) {
        this.plugin = plugin;
    }

    /** Returns a reply or null if the bot should stay quiet. */
    synchronized String reply(Persona p, ChatLine t, boolean direct) {
        String text = t.text().toLowerCase(Locale.ROOT);
        Set<String> tokens = new HashSet<>(Arrays.asList(text.split("[^a-z0-9]+")));

        if (direct && (tokens.contains("bot") || tokens.contains("ai") || tokens.contains("fake") || tokens.contains("npc"))) {
            boolean admit = plugin.getConfig().getBoolean("brain.admit-bot-when-asked", false);
            return pickLine(admit ? "chatter.admit" : "chatter.bot-joke");
        }

        for (Map<?, ?> e : plugin.knowledge().getMapList("entries")) {
            Object kws = e.get("keywords");
            if (!(kws instanceof List<?> list)) {
                continue;
            }
            for (Object o : list) {
                String kw = String.valueOf(o).toLowerCase(Locale.ROOT);
                boolean hit = kw.contains(" ") ? text.contains(kw) : tokens.contains(kw);
                if (hit) {
                    String a = answer(p, e);
                    if (a != null) {
                        return a;
                    }
                }
            }
        }

        if (containsAny(tokens, "hi", "hii", "hello", "hlo", "hey", "yo", "sup", "namaste")
                || text.contains("kya haal") || text.contains("kaise ho") || text.contains("kaisa hai")) {
            return pickLine("chatter.greet");
        }
        if (containsAny(tokens, "gg", "rip", "lol", "lmao", "haha", "noob", "op", "bruh")) {
            return pickLine("chatter.react");
        }
        return direct ? pickLine("chatter.fallback") : null;
    }

    synchronized String ambient(Persona p) {
        return pickLine("chatter.ambient");
    }

    synchronized String pickLine(String path) {
        List<String> l = plugin.knowledge().getStringList(path);
        if (l.isEmpty()) {
            return null;
        }
        String s = null;
        for (int i = 0; i < 6; i++) {
            s = l.get(rnd.nextInt(l.size()));
            if (!recent.contains(s)) {
                break;
            }
        }
        recent.addLast(s);
        while (recent.size() > 14) {
            recent.removeFirst();
        }
        return s;
    }

    private String answer(Persona p, Map<?, ?> e) {
        Object en = e.get("en");
        Object hi = e.get("hi");
        boolean wantHi = p.hinglish() && rnd.nextDouble() < 0.7;
        String s = pickFrom(wantHi ? hi : en);
        if (s == null) {
            s = pickFrom(wantHi ? en : hi);
        }
        return s;
    }

    private String pickFrom(Object o) {
        if (o instanceof List<?> l && !l.isEmpty()) {
            return String.valueOf(l.get(rnd.nextInt(l.size())));
        }
        return null;
    }

    private static boolean containsAny(Set<String> tokens, String... words) {
        for (String w : words) {
            if (tokens.contains(w)) {
                return true;
            }
        }
        return false;
    }
}
