package dev.lifepals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

/** /pals ... (permission lifepals.admin, op by default). */
final class Commands implements TabExecutor {
    private static final List<String> SUBS = List.of("status", "list", "say", "join", "leave", "reroll", "toggle", "test", "zone", "where", "visit", "bodies", "reload");
    private final LifePals plugin;

    Commands(LifePals plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (!s.hasPermission("lifepals.admin")) {
            s.sendMessage("No permission.");
            return true;
        }
        BotManager bots = plugin.bots();
        if (a.length == 0) {
            s.sendMessage("/pals <" + String.join("|", SUBS) + ">");
            return true;
        }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "status" -> {
                s.sendMessage("LifePals: " + (bots.enabled() ? "ON" : "OFF")
                        + " | mode " + plugin.getConfig().getString("brain.mode", "AUTO")
                        + " | api key " + (plugin.api().available() ? "set" : "not set")
                        + " | api calls this hour " + plugin.api().callsThisHour()
                        + " | tab list " + (bots.tabActive() ? "on" : "off") + " | bodies " + (bots.bodiesActive() ? "on" : "off") + " | bots online " + bots.onlineCount() + "/" + bots.roster().size());
            }
            case "list" -> {
                for (BotManager.Bot b : bots.roster()) {
                    s.sendMessage((b.online ? "[on]  " : "[off] ") + b.p.name() + " (" + b.p.lang() + ")");
                }
            }
            case "say" -> {
                if (a.length < 3) {
                    s.sendMessage("/pals say <bot> <message>");
                    return true;
                }
                BotManager.Bot b = bots.find(a[1]);
                if (b == null) {
                    s.sendMessage("No such bot.");
                    return true;
                }
                if (!bots.forceSay(b, String.join(" ", Arrays.copyOfRange(a, 2, a.length)))) {
                    s.sendMessage("Message blocked by the safety filter.");
                }
            }
            case "join", "leave" -> {
                if (a.length < 2) {
                    s.sendMessage("/pals " + a[0] + " <bot>");
                    return true;
                }
                BotManager.Bot b = bots.find(a[1]);
                if (b == null) {
                    s.sendMessage("No such bot.");
                    return true;
                }
                if (a[0].equalsIgnoreCase("join")) {
                    bots.join(b);
                } else {
                    bots.leave(b);
                }
            }
            case "reroll" -> {
                bots.reroll();
                s.sendMessage("Roster rerolled. Use /pals list.");
            }
            case "toggle" -> {
                bots.setEnabled(!bots.enabled());
                s.sendMessage("LifePals is now " + (bots.enabled() ? "ON" : "OFF"));
            }
            case "test" -> {
                if (a.length < 2) {
                    s.sendMessage("/pals test <message>  (private, nothing is broadcast)");
                    return true;
                }
                String msg = String.join(" ", Arrays.copyOfRange(a, 1, a.length));
                bots.test(s.getName(), msg).thenAccept(r -> Bukkit.getScheduler().runTask(plugin,
                        () -> s.sendMessage(r == null ? "(bot chose to stay silent or no bot online)" : r)));
            }
            case "zone" -> {
                if (!(s instanceof Player pl)) {
                    s.sendMessage("Run this in game, standing where the bots should hang out.");
                    return true;
                }
                int r = 30;
                if (a.length > 1) {
                    try {
                        r = Integer.parseInt(a[1]);
                    } catch (NumberFormatException ignored) {
                        // keep default
                    }
                }
                r = Math.max(5, Math.min(r, 150));
                if (bots.setZone(pl.getLocation(), r)) {
                    s.sendMessage("Bot zone set to your position, radius " + r + ".");
                } else {
                    s.sendMessage("Bodies are off (needs ProtocolLib and bodies.enabled: true).");
                }
            }
            case "bodies" -> s.sendMessage(bots.setBodies(a.length > 1 ? a[1] : ""));
            case "visit" -> {
                if (a.length < 2 || !(a[1].equalsIgnoreCase("start") || a[1].equalsIgnoreCase("stop"))) {
                    s.sendMessage("/pals visit <start|stop>");
                    return true;
                }
                s.sendMessage(bots.visit(a[1].equalsIgnoreCase("start")));
            }
            case "where" -> {
                for (String line : bots.where()) {
                    s.sendMessage(line);
                }
            }
            case "reload" -> {
                plugin.reloadAll();
                s.sendMessage("Reloaded.");
            }
            default -> s.sendMessage("/pals <" + String.join("|", SUBS) + ">");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        List<String> out = new ArrayList<>();
        if (!s.hasPermission("lifepals.admin")) {
            return out;
        }
        if (a.length == 1) {
            for (String x : SUBS) {
                if (x.startsWith(a[0].toLowerCase(Locale.ROOT))) {
                    out.add(x);
                }
            }
        } else if (a.length == 2 && List.of("say", "join", "leave").contains(a[0].toLowerCase(Locale.ROOT))) {
            for (BotManager.Bot b : plugin.bots().roster()) {
                if (b.p.name().toLowerCase(Locale.ROOT).startsWith(a[1].toLowerCase(Locale.ROOT))) {
                    out.add(b.p.name());
                }
            }
        }
        return out;
    }
}
