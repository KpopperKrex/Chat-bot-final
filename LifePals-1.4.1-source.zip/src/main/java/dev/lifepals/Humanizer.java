package dev.lifepals;

import java.util.Locale;
import java.util.Random;

/** Makes text look typed by a person: casing, small typos (+ later *fix), stretched words, typing delay. */
final class Humanizer {
    private Humanizer() {
    }

    /** text = what to send, fix = optional follow-up like "*right" (or null). */
    record Result(String text, String fix) {
    }

    static Result apply(String s, Persona p, Random r, double fixChance) {
        s = s.strip();
        if (r.nextDouble() < 0.8) {
            s = s.toLowerCase(Locale.ROOT);
        }
        while (s.endsWith(".")) {
            s = s.substring(0, s.length() - 1);
        }
        String fix = null;
        if (r.nextDouble() < p.typoRate() && s.length() >= 6) {
            int i = 1 + r.nextInt(s.length() - 3);
            char a = s.charAt(i);
            char b = s.charAt(i + 1);
            if (Character.isLetter(a) && Character.isLetter(b) && a != b) {
                int start = s.lastIndexOf(' ', i) + 1;
                int end = s.indexOf(' ', i);
                if (end == -1) {
                    end = s.length();
                }
                String original = s.substring(start, end);
                char[] c = s.toCharArray();
                c[i] = b;
                c[i + 1] = a;
                s = new String(c);
                if (original.length() >= 3 && r.nextDouble() < fixChance) {
                    fix = "*" + original;
                }
            }
        }
        if (fix == null && r.nextDouble() < 0.07) {
            s = stretch(s, r);
        }
        return new Result(s, fix);
    }

    private static String stretch(String s, Random r) {
        if (s.isEmpty()) {
            return s;
        }
        char c = s.charAt(s.length() - 1);
        return Character.isLetter(c) ? s + String.valueOf(c).repeat(1 + r.nextInt(3)) : s;
    }

    /** Typing time in ticks, based on length with some randomness. */
    static long delayTicks(String s, Random r) {
        double sec = 1.2 + s.length() * 0.09 * (0.7 + r.nextDouble() * 0.7);
        sec = Math.min(sec, 8.0);
        return (long) (sec * 20);
    }
}
