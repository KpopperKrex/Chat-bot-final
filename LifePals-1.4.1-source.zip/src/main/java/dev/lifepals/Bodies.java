package dev.lifepals;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.ProtocolManager;
import com.comphenix.protocol.events.ListenerPriority;
import com.comphenix.protocol.events.PacketAdapter;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.events.PacketEvent;
import com.comphenix.protocol.wrappers.EnumWrappers;
import com.comphenix.protocol.wrappers.Pair;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import org.bukkit.Bukkit;
import org.bukkit.HeightMap;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

/**
 * Client-side player bodies for the bots. Nothing exists on the server: no entity, no chunk
 * loading, no player data. Packets are only sent to real players who are close to a bot, and the
 * bodies walk around a zone on the surface, look at people, swing their arm, and react when hit.
 * Requires the tab-list entry (TabList) to exist first. Any packet problem disables only this feature.
 */
final class Bodies {
    private static final int ID_BASE = 1_900_000_000;
    private static final AtomicInteger IDS = new AtomicInteger(ID_BASE);
    private static final Set<Material> DANGER = EnumSet.of(Material.CACTUS, Material.MAGMA_BLOCK,
            Material.CAMPFIRE, Material.SOUL_CAMPFIRE, Material.SWEET_BERRY_BUSH, Material.FIRE, Material.SOUL_FIRE);

    private static final class Body {
        final BotManager.Bot bot;
        final int id = IDS.getAndIncrement();
        final UUID uuid;
        final ItemStack[] gear; // hand, head, chest, legs, feet
        final Set<UUID> viewers = new HashSet<>();
        Location loc;
        double sx;
        double sy;
        double sz;
        Location target;
        long idleUntil;
        long swingUntil;
        long nextSwing;
        long lastApproach;
        long lastSay;
        long lastHitSay;
        long firstHitAt;
        long destroyAt;
        long respawnAt;
        int hits;
        int kTicks;
        double kx;
        double kz;
        boolean dead;
        boolean destroyed;
        boolean wild;       // false = roams the spawn zone, true = stands somewhere in the wild
        boolean resolved;   // true once its standing position is known (chunk loaded)
        boolean leaving;    // roamer walking to the zone edge before going "rtp"
        boolean fromEdge;   // newly promoted roamer enters from the zone edge
        long leaveBy;
        long lastResolve;
        long avoidUntil;
        long relocateAt;

        Body(BotManager.Bot bot, ItemStack[] gear) {
            this.bot = bot;
            this.uuid = TabList.uuidFor(bot.p.name());
            this.gear = gear;
        }
    }

    private final LifePals plugin;
    private final BotManager bots;
    private final TabList tab;
    private final ProtocolManager pm = ProtocolLibrary.getProtocolManager();
    private final Random rnd = new Random();
    private final Map<String, BotManager.Bot> wanted = new LinkedHashMap<>();
    private final Map<String, Body> bodies = new HashMap<>();
    private final BukkitTask task;
    private final PacketAdapter listener;
    private boolean failed;
    private long lastCreateTry;
    private World world;
    private double cx;
    private double cz;
    private int radius = 30;
    private long nextRotate;
    private boolean visitActive;
    private long visitEnd;
    private long nextVisit;

    Bodies(LifePals plugin, BotManager bots, TabList tab) {
        this.plugin = plugin;
        this.bots = bots;
        this.tab = tab;
        loadZone();
        this.listener = new PacketAdapter(plugin, ListenerPriority.NORMAL, PacketType.Play.Client.USE_ENTITY) {
            @Override
            public void onPacketReceiving(PacketEvent e) {
                try {
                    int id = e.getPacket().getIntegers().read(0);
                    if (id < ID_BASE) {
                        return;
                    }
                    e.setCancelled(true); // the server has no such entity; never let it reach vanilla
                    EnumWrappers.EntityUseAction a = e.getPacket().getEnumEntityUseActions().read(0).getAction();
                    if (a != EnumWrappers.EntityUseAction.ATTACK) {
                        return;
                    }
                    Player p = e.getPlayer();
                    Bukkit.getScheduler().runTask(plugin, () -> onHit(id, p));
                } catch (Exception ex) {
                    // ignore malformed or unexpected packets
                }
            }
        };
        pm.addPacketListener(listener);
        this.nextRotate = System.currentTimeMillis() + rotateMs();
        this.nextVisit = System.currentTimeMillis() + (1 + rnd.nextInt(15)) * 60_000L;
        this.task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 40L, 2L);
    }

    // ---------------------------------------------------------------- zone

    private FileConfiguration cfg() {
        return plugin.getConfig();
    }

    void loadZone() {
        YamlConfiguration d = YamlConfiguration.loadConfiguration(new File(plugin.getDataFolder(), "data.yml"));
        String wn = d.getString("zone.world", cfg().getString("bodies.world", ""));
        World w = (wn == null || wn.isBlank()) ? null : Bukkit.getWorld(wn);
        if (w == null && !Bukkit.getWorlds().isEmpty()) {
            w = Bukkit.getWorlds().get(0);
        }
        world = w;
        if (w == null) {
            return;
        }
        if (d.contains("zone.x") && d.contains("zone.z")) {
            cx = d.getDouble("zone.x");
            cz = d.getDouble("zone.z");
        } else if (cfg().contains("bodies.center-x") && cfg().contains("bodies.center-z")) {
            cx = cfg().getDouble("bodies.center-x");
            cz = cfg().getDouble("bodies.center-z");
        } else {
            Location s = w.getSpawnLocation();
            cx = s.getX();
            cz = s.getZ();
        }
        radius = Math.max(5, d.getInt("zone.radius", cfg().getInt("bodies.radius", 30)));
    }

    /** Admin command: hang out here. Stored in data.yml so config.yml comments stay intact. */
    void setZone(Location l, int r) {
        File f = new File(plugin.getDataFolder(), "data.yml");
        YamlConfiguration d = YamlConfiguration.loadConfiguration(f);
        d.set("zone.world", l.getWorld().getName());
        d.set("zone.x", l.getX());
        d.set("zone.z", l.getZ());
        d.set("zone.radius", r);
        try {
            d.save(f);
        } catch (IOException e) {
            plugin.getLogger().warning("Could not save zone to data.yml");
        }
        reload();
    }

    void reload() {
        reset();
        loadZone();
    }

    // ---------------------------------------------------------------- bot list from BotManager

    void sync(List<BotManager.Bot> online) {
        Map<String, BotManager.Bot> want = new LinkedHashMap<>();
        for (BotManager.Bot b : online) {
            want.put(b.p.name(), b);
        }
        for (String n : new ArrayList<>(bodies.keySet())) {
            if (!want.containsKey(n)) {
                Body b = bodies.remove(n);
                if (b != null) {
                    destroyAll(b);
                }
            }
        }
        wanted.clear();
        wanted.putAll(want);
        fillRoamers();
    }

    /** Remove every body (destroy packets) but keep running. */
    void reset() {
        for (Body b : new ArrayList<>(bodies.values())) {
            destroyAll(b);
        }
        bodies.clear();
    }

    void clear() {
        task.cancel();
        reset();
        wanted.clear();
        try {
            pm.removePacketListener(listener);
        } catch (Throwable ignored) {
            // shutting down anyway
        }
    }

    void forget(UUID player) {
        for (Body b : bodies.values()) {
            b.viewers.remove(player);
        }
    }

    List<String> where() {
        List<String> out = new ArrayList<>();
        out.add("mode " + (wildOn() ? "MIXED" : "SPAWN_ONLY") + (visitsOn() ? " | visit " + (visitActive ? "ACTIVE" : "off") : ""));
        out.add("zone: " + (world == null ? "none" : world.getName()) + " " + (int) cx + "," + (int) cz + " r=" + radius
                + " | bodies " + bodies.size() + "/" + wanted.size());
        for (Body b : bodies.values()) {
            out.add((b.wild ? "[wild] " : "[spawn] ") + b.bot.p.name() + (b.resolved ? "" : " (waiting for chunk)") + " @ " + b.loc.getBlockX() + "," + b.loc.getBlockY() + "," + b.loc.getBlockZ()
                    + " viewers " + b.viewers.size() + (b.dead ? " (dead)" : ""));
        }
        return out;
    }

    // ---------------------------------------------------------------- main loop (every 2 ticks)

    private void tick() {
        if (failed || world == null || !tab.works()) {
            return;
        }
        long now = System.currentTimeMillis();
        if (now - lastCreateTry > 1500) {
            lastCreateTry = now;
            for (Map.Entry<String, BotManager.Bot> e : wanted.entrySet()) {
                if (!bodies.containsKey(e.getKey())) {
                    tryCreate(e.getValue());
                }
            }
        }
        updateVisits(now);
        if (now >= nextRotate) {
            nextRotate = now + rotateMs();
            rotate(now);
        }
        for (Body b : new ArrayList<>(bodies.values())) {
            try {
                step(b, now);
            } catch (Exception ex) {
                fail(ex);
                return;
            }
        }
    }

    private void tryCreate(BotManager.Bot bot) {
        long now = System.currentTimeMillis();
        if (!wildOn() && (roamerCount() >= roamerTarget() || !visitOpen())) {
            return; // spawn-only mode: bots only exist at spawn during a visit
        }
        Body b = new Body(bot, gearFor(bot.p));
        b.loc = new Location(world, cx, 64, cz, rnd.nextInt(360) - 180, 0f);
        if (roamerCount() < roamerTarget()) {
            b.wild = false;
            b.fromEdge = false;
            b.resolved = false;
        } else {
            pickWild(b);
        }
        b.idleUntil = now + 1000 + rnd.nextInt(4000);
        bodies.put(bot.p.name(), b);
    }

    private boolean playerNearZone() {
        double lim = radius + cfg().getInt("bodies.view-range", 48) + 16;
        for (Player p : world.getPlayers()) {
            Location l = p.getLocation();
            double dx = l.getX() - cx;
            double dz = l.getZ() - cz;
            if (dx * dx + dz * dz <= lim * lim) {
                return true;
            }
        }
        return false;
    }

    private void step(Body b, long now) {
        if (b.dead) {
            if (!b.destroyed && now >= b.destroyAt) {
                destroyAll(b);
                b.destroyed = true;
            }
            if (now >= b.respawnAt) {
                respawn(b, now);
            }
            return;
        }
        if (!b.resolved) {
            if (b.leaving) {
                bodies.remove(b.bot.p.name());
                return;
            }
            if (now - b.lastResolve >= 1000) {
                b.lastResolve = now;
                attemptResolve(b, now);
            }
            return;
        }
        updateViewers(b);
        if (b.wild) {
            stepWild(b, now);
            return;
        }
        if (b.viewers.isEmpty()) {
            if (b.leaving) {
                finishLeave(b, now);
                return;
            }
            if (now >= b.idleUntil) {
                Location spot = randomSpot();
                if (spot != null) {
                    place(b, spot.getX(), spot.getY(), spot.getZ(), rnd.nextInt(360) - 180);
                }
                b.idleUntil = now + 20_000 + rnd.nextInt(30_000);
            }
            return;
        }
        if (b.leaving && now > b.leaveBy) {
            finishLeave(b, now);
            return;
        }
        if (b.kTicks > 0) {
            knock(b);
            return;
        }
        if (b.target != null) {
            walk(b, now);
            return;
        }
        if (now >= b.idleUntil) {
            chooseNext(b, now);
            return;
        }
        idle(b, now);
    }

    /** Wild bots just stand there: look around, swing an arm now and then, no walking. */
    private void stepWild(Body b, long now) {
        if (b.viewers.isEmpty()) {
            if (now >= b.relocateAt) {
                pickWild(b);
            }
            return;
        }
        if (b.kTicks > 0) {
            knock(b);
            return;
        }
        if (now >= b.idleUntil) {
            b.swingUntil = now + 5000 + rnd.nextInt(6000);
            b.idleUntil = b.swingUntil + 8000 + rnd.nextInt(25_000);
            look(b, b.loc.getYaw(), 35f);
            return;
        }
        idle(b, now);
    }

    // ---------------------------------------------------------------- viewers

    private void updateViewers(Body b) {
        double vr = cfg().getInt("bodies.view-range", 48);
        double near2 = vr * vr;
        double keep2 = (vr + 8) * (vr + 8);
        for (Player p : world.getPlayers()) {
            UUID id = p.getUniqueId();
            double d2 = p.getLocation().distanceSquared(b.loc);
            boolean has = b.viewers.contains(id);
            if (!has && d2 <= near2 && p.getTicksLived() >= 60) {
                spawnFor(b, p);
                b.viewers.add(id);
            } else if (has && d2 > keep2) {
                destroyFor(b, p);
                b.viewers.remove(id);
            }
        }
        b.viewers.removeIf(id -> {
            Player p = Bukkit.getPlayer(id);
            return p == null || !p.isOnline() || !p.getWorld().equals(world);
        });
    }

    private Player nearestViewer(Body b, double range) {
        Player best = null;
        double bestD = range * range;
        for (UUID id : b.viewers) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) {
                continue;
            }
            double d = p.getLocation().distanceSquared(b.loc);
            if (d <= bestD) {
                bestD = d;
                best = p;
            }
        }
        return best;
    }

    // ---------------------------------------------------------------- behaviours

    private void chooseNext(Body b, long now) {
        if (b.leaving) {
            for (int i = 0; i < 8; i++) {
                Location e = edgeSpot();
                if (e != null && Math.abs(e.getY() - b.loc.getY()) <= 6) {
                    b.target = e;
                    return;
                }
            }
            b.idleUntil = now + 2000;
            return;
        }
        double roll = rnd.nextDouble();
        Player near = nearestViewer(b, 25);
        if (roll < 0.20 && near != null && now - b.lastApproach > 45_000 && now >= b.avoidUntil) {
            b.lastApproach = now;
            Vector away = b.loc.toVector().subtract(near.getLocation().toVector()).setY(0);
            if (away.lengthSquared() < 0.01) {
                away = new Vector(1, 0, 0);
            }
            away.normalize().multiply(3.0);
            double tx = near.getLocation().getX() + away.getX();
            double tz = near.getLocation().getZ() + away.getZ();
            Double ty = groundY(tx, tz);
            if (ty != null && inZone(tx, tz) && Math.abs(ty - b.loc.getY()) <= 4) {
                b.target = new Location(world, tx, ty, tz);
                if (now - b.lastSay > 60_000 && rnd.nextDouble() < 0.35) {
                    b.lastSay = now;
                    bots.sayLine(b.bot, "chatter.near-say", near.getName());
                }
                return;
            }
        }
        if (roll < 0.70) {
            for (int i = 0; i < 6; i++) {
                double ang = rnd.nextDouble() * Math.PI * 2;
                double dist = 4 + rnd.nextDouble() * 12;
                double tx = b.loc.getX() + Math.cos(ang) * dist;
                double tz = b.loc.getZ() + Math.sin(ang) * dist;
                if (!inZone(tx, tz)) {
                    continue;
                }
                Double ty = groundY(tx, tz);
                if (ty != null && Math.abs(ty - b.loc.getY()) <= 3) {
                    b.target = new Location(world, tx, ty, tz);
                    return;
                }
            }
            b.idleUntil = now + 2000;
            return;
        }
        // stand and "work": swing arm looking slightly down
        b.swingUntil = now + 4000 + rnd.nextInt(5000);
        b.idleUntil = b.swingUntil + 1000 + rnd.nextInt(2000);
        look(b, b.loc.getYaw(), 35f);
    }

    private void walk(Body b, long now) {
        double dx = b.target.getX() - b.loc.getX();
        double dz = b.target.getZ() - b.loc.getZ();
        double dist = Math.hypot(dx, dz);
        if (dist < 0.45) {
            b.target = null;
            if (b.leaving) {
                finishLeave(b, now);
                return;
            }
            b.idleUntil = now + 3000 + rnd.nextInt(7000);
            Player near = nearestViewer(b, 6);
            if (near != null) {
                lookAt(b, near);
            }
            return;
        }
        double step = Math.min(0.43, dist);
        double nx = b.loc.getX() + dx / dist * step;
        double nz = b.loc.getZ() + dz / dist * step;
        Double ny = groundY(nx, nz);
        if (ny == null || Math.abs(ny - b.loc.getY()) > 1.01) {
            b.target = null;
            b.idleUntil = now + 1500 + rnd.nextInt(2500);
            return;
        }
        float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        moveTo(b, nx, ny, nz, yaw, 0f);
    }

    private void idle(Body b, long now) {
        Player near = nearestViewer(b, 8);
        if (near != null && rnd.nextDouble() < 0.10) {
            lookAt(b, near);
        } else if (rnd.nextDouble() < 0.02) {
            look(b, b.loc.getYaw() + rnd.nextInt(81) - 40, rnd.nextInt(21) - 10);
        }
        if (now < b.swingUntil && now >= b.nextSwing) {
            swing(b);
            b.nextSwing = now + 350 + rnd.nextInt(350);
        }
    }

    private void knock(Body b) {
        double nx = b.loc.getX() + b.kx;
        double nz = b.loc.getZ() + b.kz;
        Double ny = groundY(nx, nz);
        if (ny != null && Math.abs(ny - b.loc.getY()) <= 1.01) {
            moveTo(b, nx, ny, nz, b.loc.getYaw(), 0f);
        }
        b.kx *= 0.6;
        b.kz *= 0.6;
        b.kTicks--;
    }

    private void onHit(int id, Player attacker) {
        Body b = null;
        for (Body x : bodies.values()) {
            if (x.id == id) {
                b = x;
                break;
            }
        }
        if (b == null || b.dead || !b.viewers.contains(attacker.getUniqueId())) {
            return;
        }
        long now = System.currentTimeMillis();
        if (now - b.firstHitAt > 8000) {
            b.firstHitAt = now;
            b.hits = 0;
        }
        b.hits++;
        status(b, (byte) 2); // hurt flash
        Vector away = b.loc.toVector().subtract(attacker.getLocation().toVector()).setY(0);
        if (away.lengthSquared() > 0.01) {
            away.normalize().multiply(0.35);
            b.kx = away.getX();
            b.kz = away.getZ();
            b.kTicks = 3;
        }
        b.target = null;
        if (b.hits >= Math.max(2, cfg().getInt("bodies.hits-to-die", 8))) {
            b.dead = true;
            b.kTicks = 0;
            b.destroyed = false;
            b.destroyAt = now + 1200;
            b.respawnAt = now + cfg().getInt("bodies.respawn-seconds", 25) * 1000L;
            status(b, (byte) 3); // death animation
            if (rnd.nextDouble() < 0.7) {
                bots.sayLine(b.bot, "chatter.died", attacker.getName());
            }
            return;
        }
        if (now - b.lastHitSay > 15_000 && rnd.nextDouble() < 0.5) {
            b.lastHitSay = now;
            bots.sayLine(b.bot, "chatter.hit", attacker.getName());
        }
    }

    private void respawn(Body b, long now) {
        b.dead = false;
        b.hits = 0;
        b.kTicks = 0;
        b.leaving = false;
        if (b.wild) {
            pickWild(b);
            return;
        }
        b.fromEdge = false;
        b.resolved = false; // placed again by attemptResolve
        b.idleUntil = now + 2000 + rnd.nextInt(3000);
    }

    // ---------------------------------------------------------------- roles (spawn roamers vs wild standers)

    private int roamerTarget() {
        return Math.max(0, cfg().getInt("bodies.roamers", 2));
    }

    private int roamerCount() {
        int n = 0;
        for (Body x : bodies.values()) {
            if (!x.wild && !x.leaving) {
                n++;
            }
        }
        return n;
    }

    private long rotateMs() {
        int lo = Math.max(1, cfg().getInt("bodies.rotate-minutes-min", 6));
        int hi = Math.max(lo, cfg().getInt("bodies.rotate-minutes-max", 14));
        return (lo + rnd.nextInt(hi - lo + 1)) * 60_000L;
    }

    /** Resolve a body's standing spot once the chunk is loaded (never loads chunks itself). */
    private void attemptResolve(Body b, long now) {
        if (b.wild) {
            double x = b.loc.getX();
            double z = b.loc.getZ();
            if (!world.isChunkLoaded((int) Math.floor(x) >> 4, (int) Math.floor(z) >> 4)) {
                return;
            }
            Double y = groundY(x, z);
            if (y == null) {
                pickWild(b); // water/lava/cactus: pick another spot
                return;
            }
            place(b, x, y, z, b.loc.getYaw());
        } else {
            if (!playerNearZone()) {
                return;
            }
            Location spot = null;
            for (int i = 0; i < 25 && spot == null; i++) {
                spot = b.fromEdge ? edgeSpot() : randomSpot();
            }
            if (spot == null) {
                return;
            }
            place(b, spot.getX(), spot.getY(), spot.getZ(), rnd.nextInt(360) - 180);
            b.fromEdge = false;
        }
        b.resolved = true;
        b.idleUntil = now + 1000 + rnd.nextInt(5000);
    }

    /** Pick a random standing spot in the wilderness ring (like /rtp). Y is resolved lazily. */
    private void pickWild(Body b) {
        destroyAll(b);
        Location c = world.getWorldBorder().getCenter();
        double border = world.getWorldBorder().getSize() / 2 - 20;
        double min = cfg().getInt("bodies.wild.min-radius", 300);
        double max = Math.min(cfg().getInt("bodies.wild.max-radius", 3000), border);
        if (max <= min) {
            min = Math.max(0, max / 2);
        }
        double ang = rnd.nextDouble() * Math.PI * 2;
        double dist = min + rnd.nextDouble() * Math.max(1, max - min);
        b.loc = new Location(world, c.getX() + Math.cos(ang) * dist, 64, c.getZ() + Math.sin(ang) * dist,
                rnd.nextInt(360) - 180, 0f);
        b.wild = true;
        b.resolved = false;
        b.leaving = false;
        b.target = null;
        b.hits = 0;
        b.kTicks = 0;
        b.relocateAt = System.currentTimeMillis() + (10 + rnd.nextInt(16)) * 60_000L;
    }

    /** Roamer finished walking out: says it is going to /rtp, vanishes, reappears somewhere wild. */
    private void finishLeave(Body b, long now) {
        if (!b.viewers.isEmpty() && rnd.nextDouble() < 0.6) {
            bots.sayLine(b.bot, "chatter.rtp-say", "");
        }
        if (wildOn()) {
            pickWild(b);
            return;
        }
        destroyAll(b);
        bodies.remove(b.bot.p.name());
    }

    private void promote(Body b) {
        destroyAll(b);
        b.wild = false;
        b.fromEdge = true;
        b.resolved = false;
        b.leaving = false;
        b.target = null;
    }

    private void demote(Body b, long now) {
        b.leaving = true;
        b.leaveBy = now + 90_000;
        b.target = null;
        b.idleUntil = now;
    }

    /** Make sure the configured number of bots roam spawn (promote wild ones without viewers). */
    private void fillRoamers() {
        int need = roamerTarget() - roamerCount();
        if (need <= 0) {
            return;
        }
        List<Body> wild = new ArrayList<>();
        for (Body x : bodies.values()) {
            if (x.wild && !x.dead && x.viewers.isEmpty()) {
                wild.add(x);
            }
        }
        while (need > 0 && !wild.isEmpty()) {
            promote(wild.remove(rnd.nextInt(wild.size())));
            need--;
        }
    }

    /** Alternate: one spawn roamer heads out to the wild, a wild bot takes its place at spawn. */
    private void rotate(long now) {
        List<Body> roam = new ArrayList<>();
        List<Body> wild = new ArrayList<>();
        for (Body x : bodies.values()) {
            if (x.dead) {
                continue;
            }
            if (!x.wild && !x.leaving) {
                roam.add(x);
            } else if (x.wild && x.viewers.isEmpty()) {
                wild.add(x);
            }
        }
        if (wild.isEmpty()) {
            return;
        }
        if (!roam.isEmpty() && roam.size() >= roamerTarget() && roamerTarget() > 0) {
            demote(roam.get(rnd.nextInt(roam.size())), now);
            promote(wild.get(rnd.nextInt(wild.size())));
        } else {
            fillRoamers();
        }
    }

    // ---------------------------------------------------------------- visits (spawn-only mode)

    private boolean wildOn() {
        return "MIXED".equalsIgnoreCase(cfg().getString("bodies.mode", "SPAWN_ONLY"));
    }

    private boolean visitsOn() {
        return !wildOn() && cfg().getBoolean("bodies.visits.enabled", true);
    }

    private boolean visitOpen() {
        return !visitsOn() || visitActive;
    }

    private void updateVisits(long now) {
        if (!visitsOn()) {
            return;
        }
        if (visitActive) {
            if (now >= visitEnd) {
                endVisit(now);
            }
            return;
        }
        if (now < nextVisit) {
            return;
        }
        // more likely to show up in busy hours of the day
        if (rnd.nextDouble() <= Math.max(0.1, bots.busy())) {
            startVisit(now);
        } else {
            nextVisit = now + (10 + rnd.nextInt(20)) * 60_000L;
        }
    }

    private void startVisit(long now) {
        int lo = Math.max(1, cfg().getInt("bodies.visits.min-minutes", 10));
        int hi = Math.max(lo, cfg().getInt("bodies.visits.max-minutes", 40));
        visitActive = true;
        visitEnd = now + (lo + rnd.nextInt(hi - lo + 1)) * 60_000L;
    }

    private void endVisit(long now) {
        visitActive = false;
        for (Body b : bodies.values()) {
            if (!b.wild && !b.leaving) {
                demote(b, now);
            }
        }
        int per = Math.max(1, cfg().getInt("bodies.visits.per-day", 4));
        double baseMin = 1440.0 / per;
        nextVisit = now + (long) (Math.max(20, baseMin * (0.5 + rnd.nextDouble())) * 60_000L);
    }

    /** Admin test: /pals visit start|stop */
    String forceVisit(boolean start) {
        if (!visitsOn()) {
            return "Visits are off (bodies.mode must be SPAWN_ONLY and bodies.visits.enabled true).";
        }
        long now = System.currentTimeMillis();
        if (start) {
            startVisit(now);
            return "Visit started.";
        }
        endVisit(now);
        return "Visit ended, bots are walking out.";
    }

    /** A player asked this bot for a trade/tpa/gift: walk away and ignore them for a while. */
    void avoid(String botName, Player p) {
        Body b = bodies.get(botName);
        if (b == null || p == null || !b.resolved || b.dead) {
            return;
        }
        b.avoidUntil = System.currentTimeMillis() + 180_000L;
        if (b.wild || !b.viewers.contains(p.getUniqueId())) {
            return;
        }
        Vector away = b.loc.toVector().subtract(p.getLocation().toVector()).setY(0);
        if (away.lengthSquared() < 0.01) {
            away = new Vector(1, 0, 0);
        }
        away.normalize().multiply(10);
        double tx = b.loc.getX() + away.getX();
        double tz = b.loc.getZ() + away.getZ();
        Double ty = groundY(tx, tz);
        if (ty != null && (b.leaving || inZone(tx, tz)) && Math.abs(ty - b.loc.getY()) <= 4) {
            b.target = new Location(world, tx, ty, tz);
        }
    }

    private Location edgeSpot() {
        double ang = rnd.nextDouble() * Math.PI * 2;
        double dist = radius * (0.85 + rnd.nextDouble() * 0.10);
        double x = cx + Math.cos(ang) * dist;
        double z = cz + Math.sin(ang) * dist;
        Double y = groundY(x, z);
        return y == null ? null : new Location(world, x, y, z);
    }

    // ---------------------------------------------------------------- terrain

    private boolean inZone(double x, double z) {
        double dx = x - cx;
        double dz = z - cz;
        return dx * dx + dz * dz <= (double) radius * radius;
    }

    /** Standing height on the surface at x,z, or null if unsafe/unloaded. Never loads chunks. */
    private Double groundY(double x, double z) {
        int bx = (int) Math.floor(x);
        int bz = (int) Math.floor(z);
        if (!world.isChunkLoaded(bx >> 4, bz >> 4)) {
            return null;
        }
        int top = world.getHighestBlockYAt(bx, bz, HeightMap.MOTION_BLOCKING_NO_LEAVES);
        Block ground = world.getBlockAt(bx, top, bz);
        if (ground.isLiquid() || DANGER.contains(ground.getType())) {
            return null;
        }
        return top + 1.0;
    }

    private Location randomSpot() {
        double ang = rnd.nextDouble() * Math.PI * 2;
        double dist = Math.sqrt(rnd.nextDouble()) * radius;
        double x = cx + Math.cos(ang) * dist;
        double z = cz + Math.sin(ang) * dist;
        Double y = groundY(x, z);
        return y == null ? null : new Location(world, x, y, z);
    }

    private void place(Body b, double x, double y, double z, float yaw) {
        b.loc = new Location(world, x, y, z, yaw, 0f);
        b.sx = x;
        b.sy = y;
        b.sz = z;
        b.target = null;
    }

    // ---------------------------------------------------------------- packets

    private static byte angle(float deg) {
        return (byte) (int) (deg * 256f / 360f);
    }

    private void moveTo(Body b, double nx, double ny, double nz, float yaw, float pitch) {
        long dx = Math.round(nx * 4096) - Math.round(b.sx * 4096);
        long dy = Math.round(ny * 4096) - Math.round(b.sy * 4096);
        long dz = Math.round(nz * 4096) - Math.round(b.sz * 4096);
        b.sx = nx;
        b.sy = ny;
        b.sz = nz;
        b.loc.setX(nx);
        b.loc.setY(ny);
        b.loc.setZ(nz);
        b.loc.setYaw(yaw);
        b.loc.setPitch(pitch);
        sendMoveLook(b, (short) dx, (short) dy, (short) dz, yaw, pitch);
    }

    private void look(Body b, float yaw, float pitch) {
        b.loc.setYaw(yaw);
        b.loc.setPitch(pitch);
        sendMoveLook(b, (short) 0, (short) 0, (short) 0, yaw, pitch);
    }

    private void lookAt(Body b, Player p) {
        Location t = p.getLocation();
        double dx = t.getX() - b.loc.getX();
        double dz = t.getZ() - b.loc.getZ();
        double dy = t.getY() - b.loc.getY();
        float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float pitch = (float) Math.toDegrees(-Math.atan2(dy, Math.hypot(dx, dz)));
        look(b, yaw, pitch);
    }

    private void sendMoveLook(Body b, short dx, short dy, short dz, float yaw, float pitch) {
        try {
            PacketContainer mv = pm.createPacket(PacketType.Play.Server.REL_ENTITY_MOVE_LOOK);
            mv.getIntegers().write(0, b.id);
            mv.getShorts().write(0, dx).write(1, dy).write(2, dz);
            mv.getBytes().write(0, angle(yaw)).write(1, angle(pitch));
            mv.getBooleans().write(0, true);
            PacketContainer head = pm.createPacket(PacketType.Play.Server.ENTITY_HEAD_ROTATION);
            head.getIntegers().write(0, b.id);
            head.getBytes().write(0, angle(yaw));
            toViewers(b, mv);
            toViewers(b, head);
        } catch (Throwable t) {
            fail(t);
        }
    }

    private void swing(Body b) {
        try {
            PacketContainer a = pm.createPacket(PacketType.Play.Server.ANIMATION);
            a.getIntegers().write(0, b.id).write(1, 0);
            toViewers(b, a);
        } catch (Throwable t) {
            fail(t);
        }
    }

    private void status(Body b, byte code) {
        try {
            PacketContainer s = pm.createPacket(PacketType.Play.Server.ENTITY_STATUS);
            s.getIntegers().write(0, b.id);
            s.getBytes().write(0, code);
            toViewers(b, s);
        } catch (Throwable t) {
            fail(t);
        }
    }

    private void spawnFor(Body b, Player p) {
        try {
            PacketContainer sp = pm.createPacket(PacketType.Play.Server.SPAWN_ENTITY);
            sp.getIntegers().write(0, b.id);
            sp.getUUIDs().write(0, b.uuid);
            sp.getEntityTypeModifier().write(0, EntityType.PLAYER);
            sp.getDoubles().write(0, b.loc.getX()).write(1, b.loc.getY()).write(2, b.loc.getZ());
            sp.getBytes().write(0, angle(b.loc.getPitch())).write(1, angle(b.loc.getYaw())).write(2, angle(b.loc.getYaw()));
            pm.sendServerPacket(p, sp);

            PacketContainer head = pm.createPacket(PacketType.Play.Server.ENTITY_HEAD_ROTATION);
            head.getIntegers().write(0, b.id);
            head.getBytes().write(0, angle(b.loc.getYaw()));
            pm.sendServerPacket(p, head);

            List<Pair<EnumWrappers.ItemSlot, ItemStack>> items = new ArrayList<>();
            EnumWrappers.ItemSlot[] slots = {EnumWrappers.ItemSlot.MAINHAND, EnumWrappers.ItemSlot.HEAD,
                    EnumWrappers.ItemSlot.CHEST, EnumWrappers.ItemSlot.LEGS, EnumWrappers.ItemSlot.FEET};
            for (int i = 0; i < slots.length; i++) {
                if (b.gear[i] != null) {
                    items.add(new Pair<>(slots[i], b.gear[i]));
                }
            }
            if (!items.isEmpty()) {
                PacketContainer eq = pm.createPacket(PacketType.Play.Server.ENTITY_EQUIPMENT);
                eq.getIntegers().write(0, b.id);
                eq.getSlotStackPairLists().write(0, items);
                pm.sendServerPacket(p, eq);
            }
        } catch (Throwable t) {
            fail(t);
        }
    }

    private void destroyFor(Body b, Player p) {
        try {
            PacketContainer d = pm.createPacket(PacketType.Play.Server.ENTITY_DESTROY);
            d.getIntLists().write(0, List.of(b.id));
            pm.sendServerPacket(p, d);
        } catch (Throwable t) {
            fail(t);
        }
    }

    private void destroyAll(Body b) {
        for (UUID id : new ArrayList<>(b.viewers)) {
            Player p = Bukkit.getPlayer(id);
            if (p != null && p.isOnline()) {
                destroyFor(b, p);
            }
        }
        b.viewers.clear();
    }

    private void toViewers(Body b, PacketContainer packet) {
        for (UUID id : b.viewers) {
            Player p = Bukkit.getPlayer(id);
            if (p != null && p.isOnline()) {
                pm.sendServerPacket(p, packet);
            }
        }
    }

    private void fail(Throwable t) {
        if (!failed) {
            failed = true;
            plugin.getLogger().warning("In-world bodies disabled (" + t.getClass().getSimpleName()
                    + "). Chat and tab list keep working. Set bodies.enabled: false to silence this.");
            Bukkit.getScheduler().runTask(plugin, this::reset);
        }
    }

    // ---------------------------------------------------------------- looks

    private ItemStack[] gearFor(Persona p) {
        String tier = p.daysPlaying() >= 90 ? "NETHERITE" : p.daysPlaying() >= 50 ? "DIAMOND" : "IRON";
        String weapon = (p.name().hashCode() & 1) == 0 ? "_SWORD" : "_AXE";
        return new ItemStack[]{
                item(tier + weapon), item(tier + "_HELMET"), item(tier + "_CHESTPLATE"),
                item(tier + "_LEGGINGS"), item(tier + "_BOOTS")};
    }

    private ItemStack item(String name) {
        Material m = Material.matchMaterial(name.toUpperCase(Locale.ROOT));
        return m == null ? null : new ItemStack(m);
    }
}
