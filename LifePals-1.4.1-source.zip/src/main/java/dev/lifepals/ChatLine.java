package dev.lifepals;

/** One line of recent chat. Only name + sanitized text ever leave the server. */
record ChatLine(String who, String text, boolean bot) {
}
